package com.sunsoft.subject.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.sunsoft.subject.Entity.Subject;


@Repository("/subjectRepository")
public interface SubjectRepository extends CrudRepository<Subject,String> {

}