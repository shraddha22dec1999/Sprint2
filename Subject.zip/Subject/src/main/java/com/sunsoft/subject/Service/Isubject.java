package com.sunsoft.subject.Service;

import java.util.List;


import org.springframework.stereotype.Service;

import com.sunsoft.subject.Entity.Subject;



@Service
public interface Isubject {
	public List<Subject> getAllSubject();

	public Subject save(Subject subject);
    public List<Subject> getProductById(String Sno,String SubjectName);
	

}