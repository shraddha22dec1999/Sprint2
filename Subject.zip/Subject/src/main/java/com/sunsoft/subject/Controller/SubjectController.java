package com.sunsoft.subject.Controller;

import java.util.List;


//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.sunsoft.subject.Entity.Subject;
import com.sunsoft.subject.Service.SubjectImpl;



@RestController
@CrossOrigin(origins="http://localhost:4200")
@RequestMapping("/api")
public class SubjectController {
	//private static final Logger LOG = LoggerFactory.getLogger(SubjectController.class);
@Autowired
 SubjectImpl subjectService;

	@PostMapping("/subject")
	public Subject index(@RequestParam("Sno")String Sno, @RequestParam("SubjectName")String SubjectName)
	
	{
		Subject subject1=new Subject("Sno","SubjectName");
		subject1.setSno(Sno);
		subject1.setSubjectName(SubjectName);
		
		
	return subjectService.save(subject1);
	      }
	@GetMapping("/subjects")
	  	public List<Subject> getUser()
	  	{
	  		return subjectService.getAllSubject();
	  	}
	  	
	
	    
	
	@GetMapping("/Add")  
	private List<Subject> findOne(@RequestParam("Sno")String Sno,@RequestParam("SubjectName")String SubjectName)   
	{  
		List<Subject> b=subjectService.getProductById(Sno, SubjectName);
		return b;

    }
	}
