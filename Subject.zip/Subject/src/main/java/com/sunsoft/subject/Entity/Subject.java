package com.sunsoft.subject.Entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="subject")
public class Subject {
	@Id
	
	@Column(name="Sno")
	String Sno;
	@Column(name = "SubjectName")
	String SubjectName;
	public Subject()
	{
		
	}
	public Subject(String Sno,String SubjectName) {
		super();
		this.SubjectName =SubjectName;
		this.Sno = Sno;
	}
	@Override
	public String toString() {
		return " [Sno=" + Sno + ", SubjectName=" + SubjectName + "]";
	}
	public String getSubjectName() {
		return SubjectName;
	}
	public void setSubjectName(String SubjectName) {
		this.SubjectName =SubjectName;
	}
	public String getSno() {
		return Sno;
	}
	public void setSno(String Sno) {
		this.Sno = Sno;
	}
}
	
	
	