package com.sunsoft.subject.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sunsoft.subject.Entity.Subject;
import com.sunsoft.subject.Repository.SubjectRepository;

@Service
public class SubjectImpl implements Isubject {
	@Autowired  
	SubjectRepository subjectRepository;  
	@Override
	public List<Subject> getAllSubject() {
		
		List<Subject> subject= new ArrayList<Subject>();  
		subjectRepository.findAll().forEach(subject1 -> subject.add(subject1));  
		return subject;  
		
	}

	@Override
	public Subject save(Subject subject) {
		
		return subjectRepository.save(subject);  
	}

	@Override
	public List<Subject> getProductById(String Sno, String SubjectName) {
		
		List<Subject> subjectList = new ArrayList<Subject>();
		List<Subject> subjects = (List<Subject>) subjectRepository.findAll();
		Iterator<Subject> it =subjects.iterator();
		while(it.hasNext()) {
			Subject s1 = it.next();
			if(s1.getSno().equals(Sno)&& s1.getSubjectName().equals(SubjectName))
			subjectList.add(s1);
		}
		
		
		return subjectList;
	}

	}
	


